<?php

declare(strict_types=1);

namespace EduCRM\Services;

/**
 * Activity Service
 * Tracks and reports user activity throughout the system
 */

class ActivityService
{
    private \PDO $pdo;

    // Action categories for reporting
    const ACTIONS = [
        'login' => 'User Login',
        'logout' => 'User Logout',
        'inquiry_add' => 'Added Inquiry',
        'inquiry_edit' => 'Edited Inquiry',
        'inquiry_convert' => 'Converted Inquiry',
        'inquiry_delete' => 'Deleted Inquiry',
        'student_add' => 'Added Student',
        'student_edit' => 'Edited Student',
        'task_add' => 'Created Task',
        'task_complete' => 'Completed Task',
        'task_edit' => 'Edited Task',
        'appointment_add' => 'Created Appointment',
        'appointment_edit' => 'Edited Appointment',
        'class_add' => 'Created Class',
        'enrollment_add' => 'Enrolled Student',
    {
        return self::ACTIONS[$action] ?? ucwords(str_replace('_', ' ', $action));
    }

    /**
     * Store pre-computed daily summary (for cron job)
     */
    public function storeDailySummary(int $userId, string $date): bool
    {
        $summary = $this->calculateDailySummary($userId, $date);

        $stmt = $this->pdo->prepare("
            INSERT INTO activity_daily_summary 
            (user_id, summary_date, total_actions, inquiries_added, inquiries_converted, 
             students_added, tasks_completed, appointments_created, logins)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
            total_actions = VALUES(total_actions),
            inquiries_added = VALUES(inquiries_added),
            inquiries_converted = VALUES(inquiries_converted),
            students_added = VALUES(students_added),
            tasks_completed = VALUES(tasks_completed),
            appointments_created = VALUES(appointments_created),
            logins = VALUES(logins)
        ");

        return $stmt->execute([
            $summary['user_id'],
            $summary['summary_date'],
            $summary['total_actions'],
            $summary['inquiries_added'],
            $summary['inquiries_converted'],
            $summary['students_added'],
            $summary['tasks_completed'],
            $summary['appointments_created'],
            $summary['logins']
        ]);
    }
}
