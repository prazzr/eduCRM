<?php
/**
 * Automation Module Index
 * Redirects to workflows page
 */
header('Location: workflows.php');
exit;
