-- ============================================================
-- Branch Data Isolation Migration
-- Adds branch_id to core tables and backfills from user data
-- Run this on production BEFORE deploying the PHP changes
-- ============================================================

-- 1. Tasks: add branch_id
ALTER TABLE `tasks` ADD COLUMN `branch_id` int(11) DEFAULT NULL;
ALTER TABLE `tasks` ADD KEY `fk_task_branch` (`branch_id`);
ALTER TABLE `tasks` ADD CONSTRAINT `fk_task_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL;

-- 2. Appointments: add branch_id
ALTER TABLE `appointments` ADD COLUMN `branch_id` int(11) DEFAULT NULL;
ALTER TABLE `appointments` ADD KEY `fk_appointment_branch` (`branch_id`);
ALTER TABLE `appointments` ADD CONSTRAINT `fk_appointment_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL;

-- 3. University Applications: add branch_id
ALTER TABLE `university_applications` ADD COLUMN `branch_id` int(11) DEFAULT NULL;
ALTER TABLE `university_applications` ADD KEY `fk_application_branch` (`branch_id`);
ALTER TABLE `university_applications` ADD CONSTRAINT `fk_application_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL;

-- 4. Classes: add branch_id
ALTER TABLE `classes` ADD COLUMN `branch_id` int(11) DEFAULT NULL;
ALTER TABLE `classes` ADD KEY `fk_class_branch` (`branch_id`);
ALTER TABLE `classes` ADD CONSTRAINT `fk_class_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL;

-- 5. Visa Workflows: add branch_id
ALTER TABLE `visa_workflows` ADD COLUMN `branch_id` int(11) DEFAULT NULL;
ALTER TABLE `visa_workflows` ADD KEY `fk_visa_branch` (`branch_id`);
ALTER TABLE `visa_workflows` ADD CONSTRAINT `fk_visa_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL;

-- ============================================================
-- DATA MIGRATION: Backfill branch_id from assigned users
-- ============================================================

-- Tasks: inherit branch from assigned user
UPDATE `tasks` t 
JOIN `users` u ON t.assigned_to = u.id 
SET t.branch_id = u.branch_id 
WHERE t.branch_id IS NULL AND u.branch_id IS NOT NULL;

-- Appointments: inherit branch from counselor
UPDATE `appointments` a 
JOIN `users` u ON a.counselor_id = u.id 
SET a.branch_id = u.branch_id 
WHERE a.branch_id IS NULL AND u.branch_id IS NOT NULL;

-- University Applications: inherit branch from student
UPDATE `university_applications` ua 
JOIN `users` u ON ua.student_id = u.id 
SET ua.branch_id = u.branch_id 
WHERE ua.branch_id IS NULL AND u.branch_id IS NOT NULL;

-- Classes: inherit branch from teacher
UPDATE `classes` c 
JOIN `users` u ON c.teacher_id = u.id 
SET c.branch_id = u.branch_id 
WHERE c.branch_id IS NULL AND u.branch_id IS NOT NULL;

-- Visa Workflows: inherit branch from student
UPDATE `visa_workflows` v 
JOIN `users` u ON v.student_id = u.id 
SET v.branch_id = u.branch_id 
WHERE v.branch_id IS NULL AND u.branch_id IS NOT NULL;

-- ============================================================
-- VERIFICATION: Check results
-- ============================================================
SELECT 'tasks' AS tbl, COUNT(*) AS total, SUM(branch_id IS NOT NULL) AS has_branch FROM tasks
UNION ALL
SELECT 'appointments', COUNT(*), SUM(branch_id IS NOT NULL) FROM appointments
UNION ALL
SELECT 'university_applications', COUNT(*), SUM(branch_id IS NOT NULL) FROM university_applications
UNION ALL
SELECT 'classes', COUNT(*), SUM(branch_id IS NOT NULL) FROM classes
UNION ALL
SELECT 'visa_workflows', COUNT(*), SUM(branch_id IS NOT NULL) FROM visa_workflows;
