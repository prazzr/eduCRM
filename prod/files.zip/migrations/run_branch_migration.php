<?php
/**
 * Run Branch Isolation Migration
 * usage: php migrations/run_branch_migration.php
 */

require_once __DIR__ . '/../app/bootstrap.php';

echo "Running Branch Isolation Migration...\n";

$sqlFile = __DIR__ . '/branch_isolation.sql';
if (!file_exists($sqlFile)) {
    die("Error: SQL file not found at $sqlFile\n");
}

$sqlContent = file_get_contents($sqlFile);

// Remove comments
$sqlContent = preg_replace('/--.*/', '', $sqlContent);

// Split by semicolon
$queries = explode(';', $sqlContent);

foreach ($queries as $index => $query) {
    $query = trim($query);
    if (empty($query))
        continue;

    try {
        $pdo->exec($query);
        echo "Success: " . substr(str_replace("\n", " ", $query), 0, 60) . "...\n";
    } catch (PDOException $e) {
        // Ignore specific errors related to re-running
        $msg = $e->getMessage();
        if (strpos($msg, 'Duplicate column name') !== false) {
            echo "Skipped (Column exists): " . substr(str_replace("\n", " ", $query), 0, 50) . "...\n";
        } elseif (strpos($msg, 'Duplicate key name') !== false) {
            echo "Skipped (Key exists): " . substr(str_replace("\n", " ", $query), 0, 50) . "...\n";
        } elseif (strpos($msg, 'already exists') !== false) {
            echo "Skipped (Exists): " . substr(str_replace("\n", " ", $query), 0, 50) . "...\n";
        } else {
            echo "Error: " . $msg . "\nQuery: $query\n";
        }
    }
}

echo "\nMigration Complete.\n";
