# Exports Directory

This directory stores temporarily generated export files (CSV, Excel, PDF).

Files are automatically deleted after download.

**Do not commit export files to version control.**
